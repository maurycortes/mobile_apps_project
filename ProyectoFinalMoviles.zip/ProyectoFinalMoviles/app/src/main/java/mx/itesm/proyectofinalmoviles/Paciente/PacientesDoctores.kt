package mx.itesm.proyectofinalmoviles.Paciente

class PacientesDoctores(val id_username:String, val id_doctor:String) {
    constructor() : this("", "") {

    }
}
