package mx.itesm.proyectofinalmoviles.Doctor

class Doctor(val id_doctor:String) {
    constructor() : this("") {

    }
}
