package mx.itesm.a01651377.sprint1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class PacienteApp : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_paciente_app)
    }
}
