package mx.itesm.a01651377.sprint1

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {
    var tipos_Usuarios = arrayOf("Seleccione tipo de usuario", "Doctor", "Paciente")

    lateinit var option:Spinner
    lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_Login.setOnClickListener{
            if(spinner_Tipo.selectedItem.toString().equals("Doctor")){
                if(text_Correo.text.toString().equals("doctor@hotmail.com")&&text_Password.text.toString().equals("password")){
                    val intent= Intent(this, DoctorApp::class.java)
                    startActivity(intent)
                }


            }
            else if(spinner_Tipo.selectedItem.toString().equals("Paciente")){
                if(text_Correo.text.toString().equals("paciente@hotmail.com")&&text_Password.text.toString().equals("password")){
                    val intent= Intent(this, PacienteApp::class.java)
                    startActivity(intent)
                }

            }


            /////////////////////////
            spinner_Tipo.adapter= ArrayAdapter<String> (this, android.R.layout.simple_list_item_1, tipos_Usuarios)

            option= findViewById(R.id.spinner_Tipo) as Spinner


            option.onItemClickListener = object: AdapterView.OnItemSelectedListener{
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    result.text = tipos_Usuarios.get(position)
                }
            }

                /////////////////
        }

    }



}
