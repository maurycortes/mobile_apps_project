package mx.itesm.a01651377.sprint1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class DoctorApp : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor_app)
    }
}
